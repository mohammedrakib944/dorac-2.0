export const NavLinks = [
  {
    id: 1,
    text: "Home",
    url: "/#",
  },
  {
    id: 2,
    text: "About",
    url: "/#about",
  },
  {
    id: 4,
    text: "Roadmap",
    url: "/#roadmap",
  },
  {
    id: 5,
    text: "Team",
    url: "#team",
  },
  {
    id: 6,
    text: "Learn",
    url: "/learn",
  },
];
